﻿namespace Exercicio6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Por favor entre com seu nome: ");
            string nome = Console.ReadLine().ToLower();
            int vogais = 0;

            foreach (char letra in nome)
            {
                if ("aeiou".Contains(letra))
                {
                    vogais++;
                }
            }

            Console.WriteLine($"Seu nome tem {vogais} vogais.");
        }
    }
}
