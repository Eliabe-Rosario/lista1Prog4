﻿namespace Exercicio9
{
    
        internal struct Livro
        {
            public string Titulo;
            public string Autor;
            public decimal Valor;

            public override string ToString()
            {
                return $"Título: {Titulo}, Autor: {Autor}, Valor: {Valor:C2}";
            }
        }

        class Program
        {
            static void Main(string[] args)
            {
                Livro livro;

                Console.Write("Nome do livro: ");
                livro.Titulo = Console.ReadLine();

                Console.Write("Nome do autor: ");
                livro.Autor = Console.ReadLine();

                Console.Write("Valor do livro: ");
                livro.Valor = Convert.ToDecimal(Console.ReadLine());

                
                Console.WriteLine(livro);
            }
        }
    }

