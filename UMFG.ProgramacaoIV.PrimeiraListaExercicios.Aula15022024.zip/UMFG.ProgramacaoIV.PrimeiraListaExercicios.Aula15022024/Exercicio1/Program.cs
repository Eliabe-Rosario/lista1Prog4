﻿namespace Exercicio1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Entre com o valor em real: ");
            decimal real = Convert.ToDecimal(Console.ReadLine());
            decimal taxa = 0.193259m;
            decimal dolar = real * taxa;
            Console.WriteLine($"O valor em dolar é: {dolar}");
        }
    }
}
