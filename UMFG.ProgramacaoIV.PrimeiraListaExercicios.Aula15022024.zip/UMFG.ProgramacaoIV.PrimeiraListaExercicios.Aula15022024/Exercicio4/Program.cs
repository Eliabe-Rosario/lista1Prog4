﻿namespace Exercicio4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Entre com o ano de seu nascimento: ");
            int anoNascimento = Convert.ToInt32(Console.ReadLine());
            int idade = DateTime.Now.Year - anoNascimento;
            Console.WriteLine($"Você tem: {idade} anos.");
        }
    }
}
