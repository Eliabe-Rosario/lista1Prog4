﻿namespace Exercicio8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Console.Write("Por favor entre com sua data de nascimento: ");
            int dataNasc = Convert.ToInt32(Console.ReadLine());

            int idade = DateTime.Now.Year - dataNasc;

            if (idade >= 0 && idade < 25)
            {
                Console.WriteLine("Jovem");
            }
            else if (idade >= 25 && idade < 60)
            {
                Console.WriteLine("Adulto");
            }
            else
            {
                Console.WriteLine("Idoso");
            }
        }
    }
}
