﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UMFG.ProgramacaoIV.PrimeiraListaExercicios.Aula15022024
{
    internal class Exercicio1
    {
        static void Main(string[]args)
        {
            double precoReal = 0;
            double taxa = 0.19325;
            double conversao = 0;

            Console.WriteLine("Digite o preco em Real :");
            precoReal = Double.Parse(Console.ReadLine());

            conversao = precoReal / taxa;

            Console.WriteLine("Preço em dolar : $ " + conversao + "Dolar");

            Console.ReadKey();
        } 
    }
}
