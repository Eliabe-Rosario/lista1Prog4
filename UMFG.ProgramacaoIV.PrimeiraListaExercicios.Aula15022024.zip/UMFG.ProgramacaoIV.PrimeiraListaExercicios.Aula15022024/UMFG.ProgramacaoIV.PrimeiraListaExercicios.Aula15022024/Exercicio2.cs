﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UMFG.ProgramacaoIV.PrimeiraListaExercicios.Aula15022024
{
    internal class Exercicio2
    {
        
        static void Main(string[] args)
        {
            Console.Write("Digite o valor em USD: ");
            decimal valorUSD = Convert.ToDecimal(Console.ReadLine());
            decimal taxaConversao = 5.22m;
            decimal valorBRL = valorUSD * taxaConversao;
            Console.WriteLine($"O valor em BRL é: {valorBRL:F2}");
        }
    }

}

