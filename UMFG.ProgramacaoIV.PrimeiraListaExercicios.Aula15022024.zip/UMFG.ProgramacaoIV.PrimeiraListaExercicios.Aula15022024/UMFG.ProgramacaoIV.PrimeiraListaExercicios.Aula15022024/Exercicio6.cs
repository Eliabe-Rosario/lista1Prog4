﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UMFG.ProgramacaoIV.PrimeiraListaExercicios.Aula15022024
{
    internal class Exercicio6
    {

        static void Main(string[] args)
        {
            Console.Write("Digite seu nome: ");
            string nome = Console.ReadLine().ToLower();
            int contadorVogais = 0;

            foreach (char letra in nome)
            {
                if ("aeiou".Contains(letra))
                {
                    contadorVogais++;
                }
            }

            Console.WriteLine($"O nome possui {contadorVogais} vogais.");
        }

    }
}
