﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UMFG.ProgramacaoIV.PrimeiraListaExercicios.Aula15022024
{
    internal class Exercicio3
    {
        static void Main(string[] args)
        {
            Console.Write("Informe a distância total percorrida em KM: ");
            double distanciaTotal = Convert.ToDouble(Console.ReadLine());
            Console.Write("Informe o gasto de combustível em litros: ");
            double combustivelGasto = Convert.ToDouble(Console.ReadLine());
            double mediaGasto = combustivelGasto / distanciaTotal;
            Console.WriteLine($"A média de gasto de combustível é de {mediaGasto:F2} litros por KM.");
        }
    }
}
