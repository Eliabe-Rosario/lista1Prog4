﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UMFG.ProgramacaoIV.PrimeiraListaExercicios.Aula15022024
{
    internal class Exercicio5
    {

        
    
        static void Main(string[] args)
        {
            Console.WriteLine("Selecione a operação:");
            Console.WriteLine("1. Soma");
            Console.WriteLine("2. Subtração");
            Console.WriteLine("3. Multiplicação");
            Console.WriteLine("4. Divisão");
            Console.WriteLine("5. Resto da Divisão");
            Console.Write("Opção: ");
            int opcao = Convert.ToInt32(Console.ReadLine());

            Console.Write("Digite o primeiro número: ");
            double num1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Digite o segundo número: ");
            double num2 = Convert.ToDouble(Console.ReadLine());

            switch (opcao)
            {
                case 1:
                    Console.WriteLine($"Resultado: {num1 + num2}");
                    break;
                case 2:
                    Console.WriteLine($"Resultado: {num1 - num2}");
                    break;
                case 3:
                    Console.WriteLine($"Resultado: {num1 * num2}");
                    break;
                case 4:
                    Console.WriteLine($"Resultado: {num1 / num2}");
                    break;
                case 5:
                    Console.WriteLine($"Resultado: {num1 % num2}");
                    break;
                default:
                    Console.WriteLine("Opção inválida.");
                    break;
            }
        }
    }


}

