﻿namespace Exercicio3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Calcule o gasto médio da distância que percorreu");
            Console.Write("Por favor entre com os kms que percorreu : ");
            double kmsPercorridos = Convert.ToDouble(Console.ReadLine());
            Console.Write("Por favor informe a quantidade de combustível em litros: ");
            double combustivel = Convert.ToDouble(Console.ReadLine());
            double GastoMedio = combustivel / kmsPercorridos;
            Console.WriteLine($"O seu gasto foi de  {GastoMedio} litros por KM.");
        }
    }
}
