﻿namespace Exercicio7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Por favor entre com seu nome: ");
            string nome = Console.ReadLine().ToLower();
            int consoantes = 0;

            foreach (char letra in nome)
            {
                if ("bcdfghjklmnpqrstvwxyz".Contains(letra))
                {
                    consoantes++;
                }
            }

            Console.WriteLine($"Seu nome tem {consoantes} consoantes.");
        }
    }
}
