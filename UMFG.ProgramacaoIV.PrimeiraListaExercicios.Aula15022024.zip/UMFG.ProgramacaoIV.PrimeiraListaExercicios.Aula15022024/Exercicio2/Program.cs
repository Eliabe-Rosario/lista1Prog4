﻿namespace Exercicio2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite o valor em dolar: ");
            decimal dolar = Convert.ToDecimal(Console.ReadLine());
            decimal taxa = 5.22m;
            decimal real = dolar * taxa;
            Console.WriteLine($"O valor em reais é {real}");
        }
    }
}
